import 'package:flutter/widgets.dart';

import 'dieu_khien/cai_dat_dk.dart';
import 'dieu_khien/lich_su_dk.dart';
import 'du_lieu/bo_chon_anh.dart';
import 'ocr/bo_nhan_dang.dart';

const phienBanApp = '1.0.0';

/// Các đối tượng dùng chung, đặt trên cùng cây widget. Màn hình lấy bằng `PhuThuoc.of(context)`.
/// Kiểm thử widget thay bằng bản giả (kho trong bộ nhớ, bộ nhận dạng demo, bộ chọn ảnh giả).
class PhuThuoc extends InheritedWidget {
  final DieuKhienLichSu lichSu;
  final DieuKhienCaiDat caiDat;
  final BoChonAnh chonAnh;

  /// Trả về bộ nhận dạng theo chế độ đang dùng (demo hoặc ML Kit).
  final BoNhanDang Function(bool dungDemo) layBoNhanDang;

  const PhuThuoc({
    super.key,
    required this.lichSu,
    required this.caiDat,
    required this.chonAnh,
    required this.layBoNhanDang,
    required super.child,
  });

  static PhuThuoc of(BuildContext context) => context.getInheritedWidgetOfExactType<PhuThuoc>()!;

  @override
  bool updateShouldNotify(PhuThuoc oldWidget) => false;
}
