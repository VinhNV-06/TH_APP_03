import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';

import 'app.dart';
import 'cau_hinh/cau_hinh.dart';
import 'dieu_khien/cai_dat_dk.dart';
import 'dieu_khien/lich_su_dk.dart';
import 'du_lieu/kho_cai_dat.dart';
import 'du_lieu/kho_lich_su.dart';
import 'du_lieu/luu_anh.dart';
import 'nen_tang/nen_tang.dart';
import 'nen_tang/ocr_mlkit.dart';
import 'ocr/bo_nhan_dang.dart';
import 'ocr/nhan_dang_demo.dart';
import 'phu_thuoc.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final cauHinh = CauHinh.tuMoiTruong();
  final kho = KhoPrefs();
  final caiDat = DieuKhienCaiDat(KhoCaiDat(kho), cauHinh: cauHinh, coOcrThietBi: coOcrThietBi);
  await caiDat.tai(); // đọc ngôn ngữ trước khung hình đầu để không bị nháy chữ
  final lichSu = DieuKhienLichSu(KhoLichSu(kho), kIsWeb ? LuuAnhGiuNguyen() : LuuAnhTep());

  final demo = NhanDangDemo();
  NhanDangMlKit? mlKit; // tạo khi cần lần đầu (nạp mô hình ML Kit mất một chút thời gian)
  BoNhanDang layBo(bool dungDemo) =>
      dungDemo || !coOcrThietBi ? demo : (mlKit ??= NhanDangMlKit(tepTuAsset: chepAssetRaTepTam));

  runApp(UngDung(
    boc: (child) => PhuThuoc(
      lichSu: lichSu,
      caiDat: caiDat,
      chonAnh: ChonAnh(),
      layBoNhanDang: layBo,
      child: child,
    ),
  ));
}
